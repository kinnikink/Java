import java.util.Random;

public class Stock {
    private String companyName;//String object holding name of Company
    private String companySymbol;//String object holding Stock Symbol
    private double currentPrice;//Double holding Current Price of Stock
    private double nextPrice;//Double holding Next Price of Stock
    private double randomNumber;//Double holding random Number
    /**
     * This sets the private variables to the default
     */
    public Stock() {//Assigns default values for variables
    companyName = "Microsoft";//Assigns default for company name
    companySymbol = "MSFT";//Assigns default for company symbol
    currentPrice = 46.87;//Assigns default for current price
    nextPrice = 46.87;//Assigns default for next price
    }
    /**
     * 
    * Determines if the default values should be used
    * @param cN
    * @param cS
    * @param cP
    * 
    */
    public void WhichDefaultValue(String cN, String cS, double cP) {//This sets the name, symbols, and current price
                                                                    // if they do not equal the default keyword values
        if(!(cN.contentEquals("NONE")) && !(cS.contentEquals("NA")) && cP != 0.0) {
	setName(cN);
	setSymbol(cS);
	setCurrentPrice(cP); 
        }
    }
    /**
    * Sets the private variables to the given values
    * @param n
    * @param s
    * @param cP
    * @param nP
    */
    public Stock(String n, String s, double cP, double nP) {
        companyName = n;
	companySymbol = s;
	currentPrice = cP;
	nextPrice = nP;
    }
    /**
    * This sets the company name to the given string
    * @param n
    */
    public void setName(String n){//Assigns the name to the private variable
        companyName = n;
    }
    /**
    * This sets the company symbol to the given string
    * @param s
    */
    public void setSymbol(String s) {
        companySymbol = s;//Assigns the symbol to the private variable
    }
    /**
    * This sets the current price to the given double
    * @param cP
    */
    public void setCurrentPrice(double cP) {
        if(cP > 0) {//Error Checking for: currentPrice > 0, set the value to the variable; otherwise set to 1
            currentPrice = cP;
	}//Close if statement	
	else {
            currentPrice = 1;
	}
    }
    /**
    * This sets the next price to the given double
    * @param nP
    */
    public void setNextPrice(double nP) {
        if(nP > 0) {
            nextPrice = nP;
	}//Close if statement
	else {
            nextPrice = 1;
	}
    }
    /**
    * This sets the percentage to the given double
    * @param p
    */
    public void setPercentage(double p) {
		if(p > 0) {
                    randomNumber = p;
		}
		else {
                    randomNumber = 1.00;
		}
    }
    /**
    * This returns the company name 
    * @return
    */
    public String getName() {
        return companyName;//returns the company's name
    }
    /**
    * This returns the company symbol
    * @return
    */
    public String getSymbol() {
        return companySymbol;//returns the company's symbol
    }
    /**
    * This returns the current price
    * @return
    */
    public double getCurrentPrice() {
        return currentPrice;//returns the company's current price
    }
    /**
    * This returns the next price 
    * @return
    */
    public double getNextPrice() {
        return nextPrice;//returns the next price of the company
    }
    /**
    * This returns the percentage
    * @return
    */
    public double getPercentage() {
        return randomNumber;
    }
    /**
    * This changes next price according the percentage by a negative or positive number
    */
    public void SimulatePrice() {
        priceChange();
    }
    public void priceChange() {
        boolean decide;
	double percent;	//declares a double used as the percent
	double currentPrice;//declares a double used as the current price
		
	Random randInt = new Random();
	setPercentage(randInt.nextInt(10));//This sets the percentage as a random integer between 0 and 10
	percent = getPercentage();//This sets the variable as the percentage
	currentPrice = getCurrentPrice();//This sets the variable as the current price
	Random negOrPos = new Random();//This declares the random generator object
	decide = negOrPos.nextBoolean();//This sets the next price as the current price - the percentage of current price
                                       //if decide is true
	if(decide) {
            setNextPrice(currentPrice-(currentPrice*.01*percent));
	}
	//This sets the next price as the current price + the percentage of current price
	//if the former condition is false
	else {
            setNextPrice(currentPrice+(currentPrice*.01*percent));
	}
		
    }
    /**
    * Prints the headers of each category
    */
    public void printHeaders() {
        System.out.println("STOCK\tSYMBOL\tYESTERDAY'S PRICE\tTODAY'S PRICE\tPRICE MOVEMENT\tCHANGE PERCENT");//Outputs the header names
    }	
    /**
    * This prints the Headers & stock information
    * @param cN
    * @param cS
    * @param cP
    * @param nP
    * @param rn
    */
    public void printResults(String cN, String cS, double cP, double nP, double rn) {
        System.out.printf("%s\t%s\t%.2f\t\t\t%.2f\t\t%.2f\t\t%.2f\n", cN, cS, cP, nP, nP-cP, rn);//Print results to screen for the user to see
    }	
}//