/* ========================================================================== */
/*  PROGRAM Stock Price Simulator
    AUTHOR: <Kelli Kinnikin and Alex Grant>
    COURSE NUMBER: <CIS 210>
    COURSE SECTION NUMBER: <01>
    INSTRUCTOR NAME: <Guanyu Tian>
    PROJECT NUMBER: <6>
    DUE DATE: 10/05/2017  

SUMMARY:
The main program will ask user to enter a name, symbol, current price of a stock. Then, it
simulates the prices for next 30 days. It displays the prices for the next 30 days on the
console and to a file named output.csv. The Stock class should have a SimulatePrice() method,
which increases or decreases the currentPrice by 0 - 10% randomly, such as 0.56% and 9.65%.

INPUT:
>stock's name
>symbol
>current price

OUTPUT:
>stock's name
>symbol
>currentPrice
>nextPrice
>priceChange
>priceChangePercentage 
*/
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class StockPriceSimulator {
    public static void main(String[] args) throws FileNotFoundException{
        String companyName = new String();//companyName variable
	String companySymbol = new String();//companySymbol variable
	double currentPrice = 0;//before user input:set currentPrice variable to 0
	double nextPrice = 0;//before user input: set nextPrice variable to 0 
	double percentChange = 0;//before user input: set percentChange variable to 0
	final int NUMBER_OF_DAYS = 30; 
				
	Scanner compNameInput = new Scanner(System.in);	//This creates an object for the company name input
	Scanner compSymbolInput = new Scanner(System.in);//This creates an object for the company symbol input
	Scanner currentPriceInput = new Scanner(System.in);//This creates an object for the current price input
        
	Stock object = new Stock();
	System.out.print("If the user enters NONE, NA, and 0.0 for the name of the company, the symbol, and yesterday's price ");
        //This prints out the default values
	System.out.println("respectively, it will use default values.");
	System.out.print("Please enter the name of the stock: ");
		
	companyName = compNameInput.nextLine();//User inputs the company's name
	System.out.print("Please enter the symbol of the stock: ");
	companySymbol = compSymbolInput.nextLine();//User inputs the company's symbol
	System.out.print("Please enter yesterday's price: ");
	currentPrice = currentPriceInput.nextDouble();//User inputs the company's current price 
	object.WhichDefaultValue(companyName, companySymbol, currentPrice);//This determines if the default values should be used
	object.priceChange();
	companyName = object.getName();//assigns the company name to the variable
	companySymbol = object.getSymbol();//assigns the company symbol to the variable
	currentPrice = object.getCurrentPrice();// assigns the current price to the variable
	nextPrice = object.getNextPrice();//assigns the current price to the variable
	percentChange = object.getPercentage();
	
        object.printHeaders();//This prints the category headers for each column	
        PrintWriter CSVFile = new PrintWriter("output.csv");
        StringBuilder CSVHeader = new StringBuilder();
        CSVHeader.append("companyName" + "," + "companySymbol" + "," + "currentPrice" + "," + "nextPrice" + "," + "percentChange" + "," + '\n');
        CSVFile.append(CSVHeader.toString());
	for(int i=1; i<=NUMBER_OF_DAYS; i++) {//This starts the for loop that iterates 30 times
            object.printResults(companyName, companySymbol, currentPrice, nextPrice, percentChange);// prints out the description of the stock
            StringBuilder CSVHelper = new StringBuilder();// builds a single row: has/n to move to the next row
            CSVHelper.append(companyName + ",");
            CSVHelper.append(companySymbol + ",");
            CSVHelper.append(currentPrice + ",");
            CSVHelper.append(nextPrice + ",");
            CSVHelper.append(percentChange + ",");
            CSVHelper.append('\n');
            CSVFile.append(CSVHelper.toString());
            object.setCurrentPrice(nextPrice);//This sets the current price to the value of the next price
            object.priceChange();//changes the price of the nextPrice
            currentPrice = object.getCurrentPrice();//assigns the current price to the variable
            nextPrice = object.getNextPrice();//assigns the nextPrice to the variable
            percentChange = object.getPercentage();//assigns the percentage to the variable
	}//Closes 'for' loop 
        CSVFile.close();
	compNameInput.close();
	compSymbolInput.close();
        currentPriceInput.close();
    }//Closes Main Method
}//Closes PriceStockSimulation Class